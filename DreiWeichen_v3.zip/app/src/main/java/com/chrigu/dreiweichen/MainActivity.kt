package com.chrigu.dreiweichen

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import kotlin.random.Random

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent { DreiWeichenApp() }
  }
}

private const val PREFS = "drei_weichen_prefs"
private const val KEY_BEST = "best_score"

data class RoundResult(val round: Int, val points: Int, val note: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DreiWeichenApp() {
  val ctx = LocalContext.current
  val prefs = remember { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
  var bestScore by rememberSaveable { mutableIntStateOf(prefs.getInt(KEY_BEST, 0)) }

  val totalRounds = 10
  var currentRound by rememberSaveable { mutableIntStateOf(1) }
  var rollCount by rememberSaveable { mutableIntStateOf(0) }
  var lastRoll by rememberSaveable { mutableIntStateOf(0) }
  var roundPoints by rememberSaveable { mutableIntStateOf(0) }
  var totalPoints by rememberSaveable { mutableIntStateOf(0) }
  var isRiskMode by rememberSaveable { mutableStateOf(false) }
  var riskSeenSix by rememberSaveable { mutableStateOf(false) }

  val history = remember { mutableStateListOf<RoundResult>() }

  val haptics = LocalHapticFeedback.current

  var spinTrigger by remember { mutableIntStateOf(0) }
  val rotation by animateFloatAsState(
    targetValue = spinTrigger * 360f,
    animationSpec = tween(durationMillis = 350, easing = LinearEasing),
    label = "dice-spin"
  )

  fun computeTakePoints(d: Int) = if (d in 1..3) d * 2 else d * 3

  fun resetRound() {
    rollCount = 0
    lastRoll = 0
    roundPoints = 0
    isRiskMode = false
    riskSeenSix = false
  }

  fun setBestIfNeeded(score: Int) {
    if (score > bestScore) {
      bestScore = score
      prefs.edit().putInt(KEY_BEST, score).apply()
    }
  }

  fun startNewGame() {
    currentRound = 1
    totalPoints = 0
    history.clear()
    resetRound()
  }

  fun finishRound(finalPoints: Int, note: String) {
    totalPoints += finalPoints
    setBestIfNeeded(totalPoints)
    history.add(RoundResult(currentRound, finalPoints, note))
    if (currentRound < totalRounds) {
      currentRound += 1
      resetRound()
    } else {
      resetRound()
      haptics.performHapticFeedback(
        if (totalPoints >= bestScore) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
      )
    }
  }

  MaterialTheme {
    Scaffold(
      topBar = { TopAppBar(title = { Text("Drei Weichen – Runde $currentRound/$totalRounds") }) }
    ) { pad ->
      Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Gesamt: $totalPoints", style = MaterialTheme.typography.titleLarge)
          Text("Bestscore: $bestScore", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
          Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Letzter Wurf", fontWeight = FontWeight.Bold)
            val rot = (rotation.roundToInt() % 360 + 360) % 360
            Text(text = if (lastRoll == 0) "—" else "🎲 $lastRoll", style = MaterialTheme.typography.displaySmall)
            Text("Rotation: ${rot}°")
            Text("Würfe in dieser Runde: $rollCount / 3")
            if (isRiskMode) Text("RISIKO aktiv – 3 Würfe: ≥1×6 = 25, sonst 0")
          }
        }

        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Button(
            modifier = Modifier.weight(1f),
            enabled = (rollCount < 3) && (currentRound <= totalRounds),
            onClick = {
              spinTrigger += 1
              haptics.performHapticFeedback(HapticFeedbackType.LongPress)

              val r = Random.nextInt(1, 7)
              lastRoll = r
              rollCount += 1
              if (isRiskMode) {
                if (r == 6) riskSeenSix = true
                if (rollCount == 3) {
                  val pts = if (riskSeenSix) 25 else 0
                  finishRound(pts, if (riskSeenSix) "Risiko geschafft (≥1×6)" else "Risiko verfehlt (keine 6)")
                }
              } else {
                roundPoints = computeTakePoints(r)
              }
            }
          ) { Text(if (rollCount == 0) "Würfeln" else "Nochmal würfeln") }

          Button(
            modifier = Modifier.weight(1f),
            enabled = (!isRiskMode && rollCount > 0 && currentRound <= totalRounds),
            onClick = {
              val pts = computeTakePoints(lastRoll)
              haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
              finishRound(pts, "Genommen: Wurf=$lastRoll → $pts")
            }
          ) { Text("Punkte nehmen") }
        }

        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedButton(
            modifier = Modifier.weight(1f),
            enabled = (!isRiskMode && rollCount in 0..2 && currentRound <= totalRounds),
            onClick = {
              isRiskMode = true
              riskSeenSix = false
              roundPoints = 0
              haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            }
          ) { Text("Risiko (25 oder 0)") }

          OutlinedButton(modifier = Modifier.weight(1f), onClick = { startNewGame() }) { Text("Neues Spiel") }
        }

        Spacer(Modifier.height(20.dp))
        Text("Historie", style = MaterialTheme.typography.titleMedium)

        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
          items(history) { item ->
            ListItem(
              headlineContent = { Text("Runde ${item.round}: ${item.points} Punkte") },
              supportingContent = { Text(item.note) }
            )
            Divider()
          }
        }
      }
    }
  }
}
