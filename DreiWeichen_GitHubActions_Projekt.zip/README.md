# Drei Weichen – Einspieler-Würfelspiel (APK per GitHub Actions)

**Ziel:** Ohne Android Studio lokal – APK automatisch über GitHub Actions bauen und herunterladen.

## Schritt-für-Schritt
1. Auf https://github.com ein neues Repository erstellen (z. B. `DreiWeichen`).
2. Inhalt dieses ZIPs hochladen (alle Dateien **einschliesslich** `.github/workflows/android.yml`).
3. Auf der Repo-Seite: **Actions** → Workflow **"Build Android APK"** auswählen → **Run workflow** (grüner Knopf).
4. Nach ca. 3–6 Minuten: In der Workflow-Run-Seite unter **Artifacts** findest du **DreiWeichen-debug-apk** → klicken → ZIP herunterladen.
5. Das enthaltene `app-debug.apk` auf dein Handy kopieren und installieren (Unbekannte Apps zulassen).

## Hinweise
- Diese Pipeline baut eine **Debug-APK** (für Testen und private Nutzung ideal).
- Möchtest du eine **Release-APK** (signiert): Passe den Workflow an (`gradle assembleRelease`) und füge einen Signierschritt mit Keystore-Secrets hinzu.
- Code ist in `app/src/main/java/com/chrigu/dreiweichen/MainActivity.kt`.
